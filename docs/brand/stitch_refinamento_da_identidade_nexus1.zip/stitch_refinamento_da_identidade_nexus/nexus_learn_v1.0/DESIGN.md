---
name: Nexus Learn v1.0
colors:
  surface: '#f7faf8'
  surface-dim: '#d7dbd9'
  surface-bright: '#f7faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f3'
  surface-container: '#ebefed'
  surface-container-high: '#e5e9e7'
  surface-container-highest: '#e0e3e1'
  on-surface: '#181c1c'
  on-surface-variant: '#3e4947'
  inverse-surface: '#2d3130'
  inverse-on-surface: '#eef1f0'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#674bb5'
  on-secondary: '#ffffff'
  secondary-container: '#ab8ffe'
  on-secondary-container: '#3f1e8c'
  tertiary: '#7f4025'
  on-tertiary: '#ffffff'
  tertiary-container: '#9c573a'
  on-tertiary-container: '#ffe5db'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb598'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#72361b'
  background: '#f7faf8'
  on-background: '#181c1c'
  surface-variant: '#e0e3e1'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base-unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

O design system é focado em uma experiência de aprendizado "AI-first", equilibrando a precisão técnica com o acolhimento educacional. A personalidade da marca é **calorosa, profissional e de alto contraste**, priorizando a legibilidade absoluta e a clareza funcional.

A estética segue um **Minimalismo Técnico**:
- **Clareza Radical:** Espaçamento generoso e hierarquia tipográfica rigorosa para reduzir a carga cognitiva durante o estudo.
- **Contraste Acessível:** Conformidade estrita com WCAG AA (4.5:1+) em todos os elementos de interface.
- **Identidade Multi-Vertical:** O sistema utiliza uma base neutra robusta (Slate) que permite que as cores específicas de cada vertical (Sky, Blue, Orange, Green) sinalizem o contexto do usuário sem sobrecarregar visualmente.
- **Mascote Nex:** Introdução de tons Violeta para interações com a IA, diferenciando o suporte assistido do conteúdo instrucional puro.

## Colors

A paleta é estruturada em três camadas de tokens: **Base (Primitive)**, **Semantic** e **Component**.

- **Global & Verticais:** O Teal atua como o fio condutor da marca Nexus. Cada vertical possui sua cor de destaque para cabeçalhos, estados ativos e ícones de categoria.
- **Neutral Warm (Slate):** Utilizado para superfícies e textos, garantindo que o branco puro não cause fadiga ocular, optando por tons de cinza levemente aquecidos.
- **Nex (IA):** O Violeta é reservado exclusivamente para o mascote e funcionalidades de inteligência artificial, criando uma distinção clara entre "ferramenta" e "assistente".
- **Modos de Cor:** O sistema é desenhado para inversão inteligente, onde o contraste é preservado através da seleção manual de hexadecimais específicos para Dark Mode em vez de apenas inversão de brilho.

## Typography

A tipografia é o principal pilar de diferenciação do design system:

1.  **Space Grotesk (Display/Headers):** Traz o ar tecnológico e futurista da Nexus. Deve ser usada em tamanhos grandes para títulos de módulos e seções.
2.  **Inter (Body):** Garante a melhor legibilidade possível para blocos extensos de conteúdo educativo.
3.  **JetBrains Mono (Data/Labels):** Utilizada para metadados, estatísticas de progresso, trechos de código e indicadores de "streak". Sua natureza monospaçada reforça a precisão dos dados.

**Regras de Estilo:**
- Evitar o uso de Itálico em Space Grotesk.
- Manter o `letter-spacing` negativo em títulos grandes para uma aparência mais densa e profissional.

## Layout & Spacing

O sistema utiliza uma grade fluida baseada em um multiplicador de **4px**.

- **Desktop (1280px+):** Grid de 12 colunas com margens de 32px e gutters de 24px.
- **Tablet (768px - 1024px):** Grid de 8 colunas com margens de 24px.
- **Mobile (<768px):** Grid de 4 colunas com margens de 16px.

A hierarquia visual deve ser estabelecida através do uso agressivo de whitespace (espaço em branco). Elementos relacionados devem usar `spacing-sm` ou `spacing-md`, enquanto seções distintas devem ser separadas por `spacing-2xl` ou superior.

## Elevation & Depth

Este design system rejeita efeitos de profundidade complexos em favor de uma **Arquitetura de Camadas Tonais (Tonal Layers)**.

- **Nível 0 (Background):** Slate-50 (Light) ou Slate-950 (Dark).
- **Nível 1 (Cards/Superfícies):** Branco puro (Light) ou Slate-900 (Dark). Sem sombras, apenas uma borda de 1px em Slate-200/Slate-800.
- **Nível 2 (Popovers/Modais):** Sombras ambientes sutis, altamente difundidas (Blur 20px, Opacidade 5%, Cor Slate-900).
- **Foco e Interação:** Em vez de elevação (z-index), as interações são sinalizadas por mudanças de cor de borda e backgrounds sutilmente mais claros/escuros.

## Shapes

As formas são **Rounded (0.5rem / 8px)**, criando um equilíbrio entre o rigor corporativo e a acessibilidade educacional.

- **Botões e Inputs:** 8px (padrão).
- **Cards de Conteúdo:** 16px (rounded-lg) para destacar módulos de aprendizado.
- **Avatares e Badges de Conquista:** 100% (Pill/Circle) para diferenciar elementos de gamificação e social.
- **Bordas:** Devem ser nítidas e sólidas. Não utilize gradientes em bordas.

## Components

### Botões
- **Primário:** Background na cor da vertical ativa, texto contrastante, sem gradientes.
- **IA (Nex):** Background Violeta com ícone de brilho (sparkles).
- **Estado de Foco:** Outline de 2px com offset de 2px na cor primária.

### Cards de Estudo
- Estrutura clara com `label-caps` no topo para a categoria, `headline-md` para o título e `body-sm` para a descrição. 
- Rodapé do card reservado para indicadores de progresso (barra de progresso fina em Teal ou na cor da vertical).

### Inputs e Formulários
- Labels sempre visíveis em `body-sm` Bold.
- Estados de erro utilizam a cor Red-600 com mensagens de suporte imediatas.

### Mascote Nex & Feedback
- Interações de IA devem ser encapsuladas em balões de fala com cantos arredondados assimétricos para indicar a voz do assistente.
- Uso de JetBrains Mono para "pensamentos da IA" ou processamento de dados em tempo real.

### Elementos de Gamificação
- **Streaks:** Ícones de fogo em Red-500.
- **Coins:** Ícones circulares em Amber-500 com tipografia JetBrains Mono para o valor numérico.